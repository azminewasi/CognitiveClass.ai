<a href="https://www.bigdatauniversity.com"><img src = "https://ibm.box.com/shared/static/wbqvbi6o6ip0vz55ua5gp17g4f1k7ve9.png" width = 300, align = "center"></a>

<h1 align=center><font size = 5>RADAR CHARTS</font></h1>

<hr>




## Table of Contents


<div class="alert alert-block alert-info" style="margin-top: 20px">
<li><p><a href="#ref0">Introduction</a></p></li>
<li><p><a href="#ref1">Usage scenarios</a></p></li>
<li><p><a href="#ref2">R Implementation</a></p></li>
<br>
<p></p>
Estimated Time Needed: <strong>15 min</strong>
</div>

<hr>

<a id="ref0"></a>
<h2 align=center>Introduction</h2>

Radar charts are a way to visualize and aggregate multivariate data in one plot. They are circular plots with "spokes" representing an axis for each variable in the plot. Lines are drawn through these axes to demonstrate the differences between the variable values of the subjects plotted.

<img src="https://ibm.box.com/shared/static/v6bmcclqgnnot6fha1x7exuvi966osyi.png"/>

<hr>

<a id="ref1"></a>
<h2 align=center>Usage scenarios</h2>

Radar Charts are particularly useful when dealing with multivariate data. In particular, they are especially good at showing differences between a handful of different entities with regards to a number of variables. A usual application of radar plots is, for example, demonstrating strengths or weaknesses of particular subjects, such as in sports. Another example is differentiating between the business approaches of different companies in a few categories such as marketing, investments, etc.

<hr>

<a id="ref2"></a>
<h2 align=center>R Implementation</h2>

First let's download the following libraries:

### ggplot2
`ggplot2` is our main plotting library. It is a specialized library made to create visually pleasing data visualizations. There's no need to install ggplot2 because it already exists on your Jupyter environment.

### ggradar

A ggplot2 extension that allows us to create radar graphs with a simple syntax.
The last version of this extension available on CRAN is not compatible with our R version. To circumvent this, let's download from the GitHub repository of the developer, <a href="https://github.com/ricardo-bion/ggradar">Ricardo Bion</a> .


```R
devtools::install_github("ricardo-bion/ggradar", 
                          dependencies=TRUE)
```

    Downloading GitHub repo ricardo-bion/ggradar@master
    from URL https://api.github.com/repos/ricardo-bion/ggradar/zipball/master
    Installing ggradar
    Installing extrafont
    Installing extrafontdb
    '/usr/lib/R/bin/R' --no-site-file --no-environ --no-save --no-restore --quiet  \
      CMD INSTALL '/tmp/Rtmp0ww9AD/devtools6113e839318/extrafontdb'  \
      --library='/resources/common/R/Library' --install-tests 
    
    Installing Rttf2pt1
    '/usr/lib/R/bin/R' --no-site-file --no-environ --no-save --no-restore --quiet  \
      CMD INSTALL '/tmp/Rtmp0ww9AD/devtools6117474f89/Rttf2pt1'  \
      --library='/resources/common/R/Library' --install-tests 
    
    '/usr/lib/R/bin/R' --no-site-file --no-environ --no-save --no-restore --quiet  \
      CMD INSTALL '/tmp/Rtmp0ww9AD/devtools61158220264/extrafont'  \
      --library='/resources/common/R/Library' --install-tests 
    
    Skipping install of 'extrafontdb' from a cran remote, the SHA1 (1.0) has not changed since last install.
      Use `force = TRUE` to force installation
    Installing tidyr
    Installing Rcpp
    '/usr/lib/R/bin/R' --no-site-file --no-environ --no-save --no-restore --quiet  \
      CMD INSTALL '/tmp/Rtmp0ww9AD/devtools6114bf709e7/Rcpp'  \
      --library='/resources/common/R/Library' --install-tests 
    
    '/usr/lib/R/bin/R' --no-site-file --no-environ --no-save --no-restore --quiet  \
      CMD INSTALL '/tmp/Rtmp0ww9AD/devtools6116b1cf903/tidyr'  \
      --library='/resources/common/R/Library' --install-tests 
    
    '/usr/lib/R/bin/R' --no-site-file --no-environ --no-save --no-restore --quiet  \
      CMD INSTALL  \
      '/tmp/Rtmp0ww9AD/devtools6116c078962/ricardo-bion-ggradar-559eeb7'  \
      --library='/resources/common/R/Library' --install-tests 
    


### dplyr

`dplyr` is responsible for pipe `%%` operation in R.

A pipe basically takes the output from one function and feeds it to the next function. An in-depth explanation of pipes and dplyr can be seen <a href="http://seananderson.ca/2014/09/13/dplyr-intro.html">here</a>.


```R
install.packages("dplyr")
```

    Installing package into ‘/resources/common/R/Library’
    (as ‘lib’ is unspecified)


### Scales

`scales` provides methods for automatically determining labels for axes and legends.


```R
install.packages("scales")
```

    Installing package into ‘/resources/common/R/Library’
    (as ‘lib’ is unspecified)


<hr>
Now let's load our libraries:


```R
library(ggplot2)
library(ggradar)
library(dplyr)
library(scales)
```

Now let's create our graph using the `mtcars` dataset. 



```R
#Select our dataset
mtcars %>%
  #atribute rownames to a variable
  add_rownames( var = "group" ) %>%
  #assign each variable -- car names -- to their related variables
  mutate_each(funs(rescale), -group) %>%
  #select which  data to plot
  head(3) %>% select(1:10) -> mtcars_radar
```

Now let's plot our graph!


```R
#this code will generate lots of warnings, so let's supress them
options(warn=-1)
ggradar(mtcars_radar)
```




    




![png](output_25_1.png)


The default size of the plot is too small. To enlarge our plot here on Jupyter, we need to use `IRkernel` from the library `devtools`


```R
IRkernel::set_plot_options(width=950, height=600, units='px')
ggradar(mtcars_radar)
```




    




![png](output_27_1.png)


<hr>

### About the Author:  
Hi! It's [Francisco Magioli](https://www.linkedin.com/in/franciscomagioli), the author of this notebook. I hope you found R easy to learn! There's lots more to learn about R but you're well on your way. Feel free to connect with me if you have any questions.

<hr>
Copyright &copy; 2016 [Big Data University](https://bigdatauniversity.com/?utm_source=bducopyrightlink&utm_medium=dswb&utm_campaign=bdu). This notebook and its source code are released under the terms of the [MIT License](https://bigdatauniversity.com/mit-license/).
