<a href="https://www.bigdatauniversity.com"><img src = "https://ibm.box.com/shared/static/wbqvbi6o6ip0vz55ua5gp17g4f1k7ve9.png" width = 300, align = "center"></a>

<h1 align=center><font size = 5>WAFFLE CHART</font></h1>

<hr>




## Table of Contents


<div class="alert alert-block alert-info" style="margin-top: 20px">
<li><p><a href="#ref0">Introduction</a></p></li>
<li><p><a href="#ref1">Usage scenarios</a></p></li>
<li><p><a href="#ref2">Implementation in R</a></p></li>
<br>
<p></p>
Estimated Time Needed: <strong>15 min</strong>
</div>

<hr>

<a id="ref0"></a>
<h2 align=center>Introduction</h2>

Waffle Charts are a great way of visualizing data in relation to a whole, to highlight progress against a given threshold, or when dealing with populations too varied for pie charts. Since they look very clean, most of the time they can even be used alongside with other kinds of visualizations!

<img src="https://ibm.box.com/shared/static/hrwya9577x8ufruaa4qzs3yseekytcsz.png"/>

<hr>

<a id="ref1"></a>
<h2 align=center>Usage scenarios</h2>

Waffle Charts are mainly used when composing parts of a whole, or when comparing progress against a goal. These charts usually follow other kinds of data visualization for helping the understanding of the audience. For example, you might want a Waffle Chart when plotting how the expenses of a company are composed by each type of expense, or when classifying percentages of a population at a given moment.

<hr>

<a id="ref2"></a>
<h2 align=center>Implementation in R</h2>

### ggplot2
`ggplot2` is our main plotting library. It is a specialized library made to create visually pleasing data visualizations. There's no need to install ggplot2 because it already exists on your Jupyter environment.


```R
install.packages("ggplot2")
```

    Installing package into ‘/resources/common/R/Library’
    (as ‘lib’ is unspecified)


### Waffle
Waffle is a ggplot2 extension designed for us to create Waffle charts with a simple syntax.


```R
install.packages("waffle")
```

    Installing package into ‘/resources/common/R/Library’
    (as ‘lib’ is unspecified)
    also installing the dependency ‘gridExtra’
    


Let's load our libraries:


```R
library(ggplot2)
library(waffle)
```

Let's create some data to plot! Let's try to plot the expenses in an imaginary household for the period of one year


```R
expenses <- c(`Health ($43,212)`=43212, `Education ($113,412)`=113412,
              `Transportation ($20,231)`=20231, `Entertainment ($28,145)`=28145)
```

Now let's plot our waffle chart. Our parameters are the following:
The data that you want to plot


```R
waffle(expenses/1235, rows=5, size=0.3, 
       colors=c("#c7d4b6", "#a3aabd", "#a0d0de", "#97b5cf"), 
       title="Imaginary Household Expenses Each Year", 
       xlab="1 square = $934")
```

    Warning message:
    : `panel.margin` is deprecated. Please use `panel.spacing` property instead




    




![png](output_19_2.png)


The default size of the plot is too small. It can't even display the title properly! 

To enlarge our plot here on Jupyter, we need to use IRkernel from the library devtools


```R
IRkernel::set_plot_options(width=950, height=600, units='px')
waffle(expenses/1235, rows=5, size=0.3, 
       colors=c("#c7d4b6", "#a3aabd", "#a0d0de", "#97b5cf"), 
       title="Imaginary Household Expenses Each Year", 
       xlab="1 square = $934")
```

    Warning message:
    : `panel.margin` is deprecated. Please use `panel.spacing` property instead




    




![png](output_21_2.png)


<hr>

### Bibliography:
https://www.r-bloggers.com/making-waffle-charts-in-r-with-the-new-waffle-package/

<hr>

### About the Author:  
Hi! It's [Francisco Magioli](https://www.linkedin.com/in/franciscomagioli), the author of this notebook. I hope you found R easy to learn! There's lots more to learn about R but you're well on your way. Feel free to connect with me if you have any questions.

<hr>
Copyright &copy; 2016 [Big Data University](https://bigdatauniversity.com/?utm_source=bducopyrightlink&utm_medium=dswb&utm_campaign=bdu). This notebook and its source code are released under the terms of the [MIT License](https://bigdatauniversity.com/mit-license/).
