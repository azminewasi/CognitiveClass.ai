<center><img src = "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork/labs/module%201/images/IDSNlogo.png" width = 250></center>

<h1 align=center><font size = 5>Hands-on Lab: Creating and Querying Database Objects from R</h1>


<br>


### Welcome!


In this hands-on lab, we will create and query database objects from an R notebook in Jupyter, and use ggplot2 to plot the data using R libraries.


<div class="alert alert-block alert-info" style="margin-top: 20px">
<h3>Tasks</h3>
<ol><ol><ol>
<li><a href="#ref4a">Pre-requisites & Dataset</a></li>
<li><a href="#ref4b">Load RODBC</a></li>
<li><a href="#ref4c">Create a database connection</a></li>
<li><a href="#ref4d">Create a connection string and connect to the database</a></li>
<li><a href="#ref4e">View database and driver information</a></li>
<li><a href="#ref4f">Create the tables</a></li>
<li><a href="#ref4g">Load data into the database</a></li>
<li><a href="#ref4h">Fetch data from the database</a></li>
<li><a href="#ref4i">Plot the data (using ggplot2)</a></li>
<li><a href="#ref4j">Dis-connect</a></li>
</ol></ol></ol>
<br>
Estimated Time Needed: <strong>30 min</strong>
</div>


<a id="ref4a"></a>

### a. Pre-requisites & Dataset

**Pre-requisite**: In this lab we will use Jupyter Notebooks within SN Labs to access data in a Db2 on Cloud database using RODBC.  Information about Jupyter notebooks, SN Labs, and Db2 services is provided in the previous labs.

**Dataset used in this lab**: For this lab we will utilize the Ontario public schools enrollment dataset. This data set is available under the Open Government License – Ontario and sourced from: [https://www.ontario.ca/data/ontario-public-schools-enrolment](https://www.ontario.ca/data/ontario-public-schools-enrolment?cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ)

For simplicity we have already split it into two separate files: [board.csv](https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork/labs/Lab%20-%20Creating%20and%20Querying%20Database%20Objects%20from%20R/board.csv) and [school.csv](https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork/labs/Lab%20-%20Creating%20and%20Querying%20Database%20Objects%20from%20R/school.csv).

Prior to starting the lab, ensure the data set files are present in the "/resources/data/samples/osb/" folder under My Data.


<a id="ref4b"></a>

### b. Load RODBC

The RODBC package and the ODBC driver for Db2 are pre-installed on your workbench. Let’s load the RODBC package by clicking on the following cell and executing it (Shift+Enter):



```R
library(RODBC);
```

<a id="ref4c"></a>

### c. Create a database connection



```R
dsn_driver <- "{IBM DB2 ODBC Driver}"
dsn_database <- "BLUDB"            
dsn_hostname <- "dashdb-txn-sbox-yp-dal09-08.services.dal.bluemix.net" 
dsn_port <- "50000"                
dsn_protocol <-"TCPIP"           
dsn_uid <- "vgh86276"        
dsn_pwd <- "5ft1hr51@rfbgt26"  
```

IBM DB2 ODBC Driver<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the <...>
dsn_driver <- "{...}"
dsn_database <- "..."            
dsn_hostname <- "<Enter Hostname>" 
dsn_port <- "..."                
dsn_protocol <- "..."            
dsn_uid <- "<Enter UserID>"        
dsn_pwd <- "<Enter Password>"   
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
#Enter the values for you database connection
dsn_driver <- "{IBM DB2 ODBC Driver}"
dsn_database <- "BLUDB"            # e.g. "BLUDB"
dsn_hostname <- "<Enter Hostname>" # e.g.: "dashdb-txn-sbox-yp-dal09-11.services.dal.bluemix.net"
dsn_port <- "50000"                # e.g. "50000" 
dsn_protocol <- "TCPIP"            # i.e. "TCPIP"
dsn_uid <- "<Enter UserID>"        # e.g. "zjh17769"
dsn_pwd <- "<Enter Password>"      # e.g. "zcwd4+8gbq9bm5k4"  
```

</details>


<a id="ref4d"></a>

### d. Create a connection string and connect to the database



```R
conn_path <- paste("DRIVER=",dsn_driver,
                  ";DATABASE=",dsn_database,
                  ";HOSTNAME=",dsn_hostname,
                  ";PORT=",dsn_port,
                  ";PROTOCOL=",dsn_protocol,
                  ";UID=",dsn_uid,
                  ";PWD=",dsn_pwd,sep="")
conn <- odbcDriverConnect(conn_path)
conn
```


    RODBC Connection 1
    Details:
      case=nochange
      DRIVER={IBM DB2 ODBC DRIVER}
      UID=vgh86276
      PWD=******
      DATABASE=BLUDB
      HOSTNAME=dashdb-txn-sbox-yp-dal09-08.services.dal.bluemix.net
      PORT=50000
      PROTOCOL=TCPIP


<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
conn_path <- paste("DRIVER=",...,
                  ";DATABASE=",...,
                  ";HOSTNAME=",...,
                  ";PORT=",...,
                  ";PROTOCOL=",...,
                  ";UID=",...,
                  ";PWD=",dsn_...,...="")
conn <- odbcDriverConnect(conn_path)
conn
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
conn_path <- paste("DRIVER=",dsn_driver,
                  ";DATABASE=",dsn_database,
                  ";HOSTNAME=",dsn_hostname,
                  ";PORT=",dsn_port,
                  ";PROTOCOL=",dsn_protocol,
                  ";UID=",dsn_uid,
                  ";PWD=",dsn_pwd,sep="")
conn <- odbcDriverConnect(conn_path)
conn
```

</details>


<a id="ref4e"></a>

### e. View database and driver information



```R
sql.info <- sqlTypeInfo(conn)
conn.info <- odbcGetInfo(conn)
conn.info["DBMS_Name"]
conn.info["DBMS_Ver"]
conn.info["Driver_ODBC_Ver"]
```


<strong>DBMS_Name:</strong> 'DB2/LINUXX8664'



<strong>DBMS_Ver:</strong> '11.01.0004'



<strong>Driver_ODBC_Ver:</strong> '03.51'


<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
sql.... <- sql...(conn)
conn.... <- odbc...(conn)
conn....["..._Name"]
conn....["..._Ver"]
conn....["Driver_..._Ver"]
conn
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
#View database and driver information
sql.info <- sqlTypeInfo(conn)
conn.info <- odbcGetInfo(conn)
conn.info["DBMS_Name"]
conn.info["DBMS_Ver"]
conn.info["Driver_ODBC_Ver"]
```

</details>


<a id="ref4f"></a>

### f. Create the tables

You will need to _remove_ the BOARD and SCHOOL tables in case they already exist.
<br>
**Note: Your Db2 non-system Schema name is your userID/username in uppercase used in creating database connection.**



```R
myschema <- "ZJH17769" # e.g. "ZJH17769"
tables <- c("BOARD", "SCHOOL")
    
    for (table in tables){  
      # Drop School table if it already exists
      out <- sqlTables(conn, tableType = "TABLE", schema = myschema, tableName =table)
      if (nrow(out)>0) {
        err <- sqlDrop (conn, paste(myschema,".",table,sep=""), errors=FALSE)  
        if (err==-1){
          cat("An error has occurred.\n")
          err.msg <- odbcGetErrMsg(conn)
          for (error in err.msg) {
            cat(error,"\n")
          }
        } else {
          cat ("Table: ",  myschema,".",table," was dropped\n")
        }
      } else {
          cat ("Table: ",  myschema,".",table," does not exist\n")
      }
    }
```

    Table:  ZJH17769 . BOARD  does not exist
    Table:  ZJH17769 . SCHOOL  does not exist


<details>
<summary>Click here to view/hide hint</summary>
<p>

```
myschema <- "..."
tables <- c("...", "...L")
    
    for (table in ...){  
      # Drop ... table if it already exists
      out <- sql...(conn, table... = "...", schema = my..., ...Name =table)
      if (nrow(...)>0) {
        err <- sql... (conn, paste(my...,".",...,...=""), errors=...)  
        if (err==-1){
          ...("An error has occurred.\n")
          err.... <- odbc...Msg(conn)
          for (error in ....msg) {
            cat(...,"\n")
          }
        } else {
          cat ("...: ",  my...,".",table," was ...\n")
        }
      } else {
          cat ("...: ",  my...,".",table," does not ...\n")
      }
    }
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
myschema <- "<Enter Schema>" # e.g. "ZJH17769"
tables <- c("BOARD", "SCHOOL")
    
    for (table in tables){  
      # Drop School table if it already exists
      out <- sqlTables(conn, tableType = "TABLE", schema = myschema, tableName =table)
      if (nrow(out)>0) {
        err <- sqlDrop (conn, paste(myschema,".",table,sep=""), errors=FALSE)  
        if (err==-1){
          cat("An error has occurred.\n")
          err.msg <- odbcGetErrMsg(conn)
          for (error in err.msg) {
            cat(error,"\n")
          }
        } else {
          cat ("Table: ",  myschema,".",table," was dropped\n")
        }
      } else {
          cat ("Table: ",  myschema,".",table," does not exist\n")
      }
    }
```

</details>


Let’s create the BOARD table in the database.



```R
df1 <- sqlQuery(conn, "CREATE TABLE BOARD (
                            B_ID CHAR(6) NOT NULL, 
                            B_NAME VARCHAR(75) NOT NULL, 
                            TYPE VARCHAR(50) NOT NULL, 
                            LANGUAGE VARCHAR(50), 
                            PRIMARY KEY (B_ID))", 
                errors=FALSE)
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
df1 <- sql...(conn, "CREATE ... BOARD (
                            B_ID ...(6) NOT ..., 
                            B_NAME ...(75) NOT ..., 
                            TYPE ...(50) NOT ..., 
                            LANGUAGE ...(50), 
                            ... KEY (B_ID))", 
                ...=FALSE)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
df1 <- sqlQuery(conn, "CREATE TABLE BOARD (
                            B_ID CHAR(6) NOT NULL, 
                            B_NAME VARCHAR(75) NOT NULL, 
                            TYPE VARCHAR(50) NOT NULL, 
                            LANGUAGE VARCHAR(50), 
                            PRIMARY KEY (B_ID))", 
                errors=FALSE)
```

</details>


Check if successful



```R
if (df1 == -1){
  cat ("An error has occurred.\n")
  msg <- odbcGetErrMsg(conn)
  print (msg)
} else {
  cat ("Table was created successfully.\n")
}
```

    Table was created successfully.


<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
if (... == -1){
  cat ("An ... has occurred.\n")
  msg <- odbc...Msg(conn)
  print (...)
} else {
  cat ("Table was ... ....\n")
}
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
if (df1 == -1){
  cat ("An error has occurred.\n")
  msg <- odbcGetErrMsg(conn)
  print (msg)
} else {
  cat ("Table was created successfully.\n")
}
```

</details>


Now let’s create the SCHOOL table.



```R
df2 <- sqlQuery(conn, "CREATE TABLE SCHOOL (
                  B_ID CHAR(6) NOT NULL, 
                  S_ID CHAR(6) NOT NULL, 
                  S_NAME VARCHAR(100), 
                  LEVEL VARCHAR(70), 
                  ENROLLMENT INTEGER WITH DEFAULT 10,
                  PRIMARY KEY (B_ID, S_ID))", errors=FALSE)
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
df2 <- sql...(conn, "CREATE ... SCHOOL (
                  B_ID ...(6) NOT NULL, 
                  S_ID ...(6) NOT NULL, 
                  S_NAME ...(100), 
                  LEVEL ...(70), 
                  ENROLLMENT ... WITH ... 10,
                  PRIMARY ... (B_ID, S_ID))", ...=FALSE)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
df2 <- sqlQuery(conn, "CREATE TABLE SCHOOL (
                  B_ID CHAR(6) NOT NULL, 
                  S_ID CHAR(6) NOT NULL, 
                  S_NAME VARCHAR(100), 
                  LEVEL VARCHAR(70), 
                  ENROLLMENT INTEGER WITH DEFAULT 10,
                  PRIMARY KEY (B_ID, S_ID))", errors=FALSE)
```

</details>


Check if successful.



```R
if (df2 == -1){
  cat ("An error has occurred.\n")
  msg <- odbcGetErrMsg(conn)
  print (msg)
} else {
  cat ("Table was created successfully.\n")
}
```

    Table was created successfully.


<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
if (... == -1){
  cat ("An ... has occurred.\n")
  msg <- odbc...Msg(conn)
  print (...)
} else {
  cat ("Table was ... ....\n")
}
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
if (df2 == -1){
  cat ("An error has occurred.\n")
  msg <- odbcGetErrMsg(conn)
  print (msg)
} else {
  cat ("Table was created successfully.\n")
}
```

</details>


<a id="ref4g"></a>

### g. Load the data into the database


Fetch the tables present in the current database schema.



```R
tab.frame <- sqlTables(conn, schema=myschema)
nrow(tab.frame)
tab.frame$TABLE_NAME
```


0






<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
tab.... <- sql...(conn, ...=myschema)
n...(tab....)
tab....$..._NAME
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
tab.frame <- sqlTables(conn, schema=myschema)
nrow(tab.frame)
tab.frame$TABLE_NAME
```

</details>


Print column 4, 6, 7, 18 details for the tables BOARD and SCHOOL



```R
for (table in tables){  
        cat ("\nColumn info for table", table, ":\n")
        col.detail <- sqlColumns(conn, table)
        print(col.detail[c(4,6,7,18)], row.names=FALSE)
}
```

    
    Column info for table BOARD :
     COLUMN_NAME TYPE_NAME COLUMN_SIZE IS_NULLABLE
            B_ID      CHAR           6          NO
          B_NAME   VARCHAR          75          NO
            TYPE   VARCHAR          50          NO
        LANGUAGE   VARCHAR          50         YES
    
    Column info for table SCHOOL :
     COLUMN_NAME TYPE_NAME COLUMN_SIZE IS_NULLABLE
            B_ID      CHAR           6          NO
            S_ID      CHAR           6          NO
          S_NAME   VARCHAR         100         YES
           LEVEL   VARCHAR          70         YES
      ENROLLMENT   INTEGER          10         YES


<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
for (table in ...){  
        cat ("\n... info for table", ..., ":\n")
        col.detail <- sqlColumns(conn, ...)
        print(col....[c(4,6,7,18)], row....=FALSE)
}
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
for (table in tables){  
        cat ("\nColumn info for table", table, ":\n")
        col.detail <- sqlColumns(conn, table)
        print(col.detail[c(4,6,7,18)], row.names=FALSE)
}
```

</details>


Load the data from the board.csv into the BOARD dataframe.



```R
boarddf <- read.csv("board.csv", header = FALSE)
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
board... <- ....csv("/resources/.../samples/.../board.csv", header = ...)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
boarddf <- read.csv("/resources/data/samples/osb/board.csv", header = FALSE)
```

</details>


Display initial data from the BOARD dataframe.



```R
head(boarddf)
```


<table>
<caption>A data.frame: 6 × 4</caption>
<thead>
	<tr><th></th><th scope=col>V1</th><th scope=col>V2</th><th scope=col>V3</th><th scope=col>V4</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>B28010</td><td>Algoma DSB                  </td><td>Public        </td><td>English</td></tr>
	<tr><th scope=row>2</th><td>B67202</td><td>Algonquin and Lakeshore CDSB</td><td>Roman Catholic</td><td>English</td></tr>
	<tr><th scope=row>3</th><td>B66010</td><td>Avon Maitland DSB           </td><td>Public        </td><td>English</td></tr>
	<tr><th scope=row>4</th><td>B66001</td><td>Bluewater DSB               </td><td>Public        </td><td>English</td></tr>
	<tr><th scope=row>5</th><td>B67164</td><td>Brant Haldimand Norfolk CDSB</td><td>Roman Catholic</td><td>English</td></tr>
	<tr><th scope=row>6</th><td>B67008</td><td>Bruce-Grey CDSB             </td><td>Roman Catholic</td><td>English</td></tr>
</tbody>
</table>



<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
...(board...)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
head(boarddf)
```

</details>


Save the dataframe to the database table BOARD.



```R
sqlSave(conn, boarddf, "BOARD", append=TRUE, fast=FALSE, rownames=FALSE, colnames=FALSE, verbose=FALSE)
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
sql...(conn, ...df, "BOARD", ...=TRUE, ...=FALSE, row...=FALSE, col...=FALSE)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
sqlSave(conn, boarddf, "BOARD", append=TRUE, fast=FALSE, rownames=FALSE, colnames=FALSE, verbose=FALSE)
```

</details>


Load the data from the school.csv into the SCHOOL dataframe



```R
schooldf <- read.csv("school.csv", header = FALSE)
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
school... <- ....csv("/resources/.../samples/osb/....csv", ... = FALSE)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
schooldf <- read.csv("/resources/data/samples/osb/school.csv", header = FALSE)
```

</details>


Display some records from the beginning of the SCHOOL dataframe.



```R
head(schooldf)
```


<table>
<caption>A data.frame: 6 × 5</caption>
<thead>
	<tr><th></th><th scope=col>V1</th><th scope=col>V2</th><th scope=col>V3</th><th scope=col>V4</th><th scope=col>V5</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>B28010</td><td>891240</td><td>Alexander Henry HS            </td><td>Secondary </td><td>145</td></tr>
	<tr><th scope=row>2</th><td>B28010</td><td>902344</td><td>Algoma Education Connection SS</td><td>Secondary </td><td>385</td></tr>
	<tr><th scope=row>3</th><td>B28010</td><td> 19186</td><td>Anna McCrea PS                </td><td>Elementary</td><td>177</td></tr>
	<tr><th scope=row>4</th><td>B28010</td><td> 67679</td><td>Arthur Henderson PS           </td><td>Elementary</td><td>104</td></tr>
	<tr><th scope=row>5</th><td>B28010</td><td> 28932</td><td>Aweres PS                     </td><td>Elementary</td><td> 95</td></tr>
	<tr><th scope=row>6</th><td>B28010</td><td> 43362</td><td>Ben R McMullin PS             </td><td>Elementary</td><td>241</td></tr>
</tbody>
</table>



<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
...(school...)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
head(schooldf)
```

</details>


Change the encoding of the 3rd column character vector from latin1 to ASCII//TRANSLIT



```R
schooldf$V3 <- iconv(schooldf$V3, "latin1", "ASCII//TRANSLIT")
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
...df$V3 <- i...(...df$V3, "latin1", "ASCII//TRANSLIT")
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
schooldf$V3 <- iconv(schooldf$V3, "latin1", "ASCII//TRANSLIT")
```

</details>


Save the dataframe to the database table SCHOOL.



```R
sqlSave(conn, schooldf, "SCHOOL", append=TRUE, fast=FALSE, rownames=FALSE, colnames=FALSE, verbose=FALSE)
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
sql...(conn, school..., "SCHOOL", append=..., fast=..., row...=FALSE, col...=FALSE)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
#NOTE: This may take a long time because of the large size of the database. When there is lot of data to insert in the database it may be faster to use the native LOAD utility of the database instead of through R.

sqlSave(conn, schooldf, "SCHOOL", append=TRUE, fast=FALSE, rownames=FALSE, colnames=FALSE, verbose=FALSE)
```

</details>


<a id="ref4h"></a>

### h. Fetch data from the database


Fetch the data from the database table BOARD and display some rows from the end of the data.



```R
boarddb <- sqlFetch(conn, "BOARD")
tail(boarddb)
```


<table>
<caption>A data.frame: 6 × 4</caption>
<thead>
	<tr><th></th><th scope=col>B_ID</th><th scope=col>B_NAME</th><th scope=col>TYPE</th><th scope=col>LANGUAGE</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>71</th><td>B67148</td><td>Waterloo CDSB      </td><td>Roman Catholic</td><td>English</td></tr>
	<tr><th scope=row>72</th><td>B66176</td><td>Waterloo Region DSB</td><td>Public        </td><td>English</td></tr>
	<tr><th scope=row>73</th><td>B67130</td><td>Wellington CDSB    </td><td>Roman Catholic</td><td>English</td></tr>
	<tr><th scope=row>74</th><td>B67024</td><td>Windsor-Essex CDSB </td><td>Roman Catholic</td><td>English</td></tr>
	<tr><th scope=row>75</th><td>B67075</td><td>York CDSB          </td><td>Roman Catholic</td><td>English</td></tr>
	<tr><th scope=row>76</th><td>B66095</td><td>York Region DSB    </td><td>Public        </td><td>English</td></tr>
</tbody>
</table>



<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
...db <- sql...(conn, "...")
...(board...)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
boarddb <- sqlFetch(conn, "BOARD")
tail(boarddb)
```

</details>


Fetch the data from the database table SCHOOL and and display some rows from the end of the data.



```R
schooldb <- sqlFetch(conn, "SCHOOL")
tail(schooldb)
```


<table>
<caption>A data.frame: 6 × 5</caption>
<thead>
	<tr><th></th><th scope=col>B_ID</th><th scope=col>S_ID</th><th scope=col>S_NAME</th><th scope=col>LEVEL</th><th scope=col>ENROLLMENT</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>4894</th><td>B66095</td><td>634565</td><td>Windham Ridge PS  </td><td>Elementary</td><td>846</td></tr>
	<tr><th scope=row>4895</th><td>B66095</td><td>549380</td><td>Wismer PS         </td><td>Elementary</td><td>511</td></tr>
	<tr><th scope=row>4896</th><td>B66095</td><td>954292</td><td>Woodbridge College</td><td>Secondary </td><td>985</td></tr>
	<tr><th scope=row>4897</th><td>B66095</td><td>617318</td><td>Woodbridge PS     </td><td>Elementary</td><td>504</td></tr>
	<tr><th scope=row>4898</th><td>B66095</td><td>618896</td><td>Woodland PS       </td><td>Elementary</td><td>442</td></tr>
	<tr><th scope=row>4899</th><td>B66095</td><td>624101</td><td>Yorkhill E S      </td><td>Elementary</td><td>293</td></tr>
</tbody>
</table>



<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
...db <- sql...(conn, "...")
tail(...db)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
schooldb <- sqlFetch(conn, "SCHOOL")
tail(schooldb)
```

</details>


<a id="ref4i"></a>

### i. Plot the data (using ggplot2)



```R
library(ggplot2);
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
...(gg...2);
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
library(ggplot2);
```

</details>


Get the elementary school data from the database from both tables in descending sequence.



```R
elequery <- query <- paste("select s.enrollment as ENROLLMENT 
from school s, board b 
where b.b_name = 'Toronto DSB' and b.b_id=s.b_id 
and s.level = 'Elementary' 
order by enrollment desc")
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
...query <- ... <- paste("... s.enrollment as ... 
from ... s, ... b 
where b.b_... = 'Toronto DSB' and b.b_id=s.... 
and ....level = 'Elementary' 
order by ... desc")
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
elequery <- query <- paste("select s.enrollment as ENROLLMENT 
from school s, board b 
where b.b_name = 'Toronto DSB' and b.b_id=s.b_id 
and s.level = 'Elementary' 
order by enrollment desc")
```

</details>


create the elementary school dataframe.



```R
eledf <- sqlQuery(conn, elequery)
dim(eledf)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>476</li><li>1</li></ol>



<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
ele... <- sql...(conn, ...query)
dim(...df)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
eledf <- sqlQuery(conn, elequery)
dim(eledf)
```

</details>


Create a density plot of elementary school enrollments.



```R
qplot(ENROLLMENT, data=eledf, geom="density",  main="TDSB School Size - Elementary")
```




![png](output_99_1.png)


<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
q...(ENROLLMENT, ...=eledf, ...="density",  ...="TDSB School Size - ...")
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
qplot(ENROLLMENT, data=eledf, geom="density",  main="TDSB School Size - Elementary")
```

</details>


Create the secondary school enrollments query in descending sequence.



```R
secquery <- paste("select s.enrollment as ENROLLMENT 
from school s, board b 
where b.b_name = 'Toronto DSB' and b.b_id=s.b_id 
and s.level = 'Secondary' 
order by enrollment desc")
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
sec... <- paste("... s.enrollment as ... 
from ... s, board b 
where b.b_... = 'Toronto ...' and b.b_id=s.... 
and s.... = 'Secondary' 
order by ... desc")
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
secquery <- paste("select s.enrollment as ENROLLMENT 
from school s, board b 
where b.b_name = 'Toronto DSB' and b.b_id=s.b_id 
and s.level = 'Secondary' 
order by enrollment desc")
```

</details>


Create the dataframe using the data in the database.



```R
secdf <- sqlQuery(conn, secquery)
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
secdf <- sql...(conn, sec...)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
secdf <- sqlQuery(conn, secquery)
```

</details>


Create a density plot of secondary school enrollments.



```R
qplot(ENROLLMENT, data=secdf, geom="density", main="TDSB School Size - Secondary")
```

    Warning message:
    “Removed 2 rows containing non-finite values (stat_density).”




![png](output_111_2.png)


<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
q...(ENROLLMENT, ...=secdf, ...="density", ...="TDSB School Size - ...")
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
qplot(ENROLLMENT, data=secdf, geom="density", main="TDSB School Size - Secondary")
```

</details>


Query the BOARD database for enrollments.



```R
denquery <- paste("select b.b_name, s.s_name, level as LEVEL, enrollment 
 from board b, school s where b.b_id = s.b_id and b.b_name = 'Toronto DSB'")
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
den... <- paste("select b.b_..., s.s_..., level as ..., ... 
 from board b, ... s where b.... = s.b_id and b.b_... = 'Toronto DSB'")
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
denquery <- paste("select b.b_name, s.s_name, level as LEVEL, enrollment 
 from board b, school s where b.b_id = s.b_id and b.b_name = 'Toronto DSB'")
```

</details>


Query the database.



```R
dendf <- sqlQuery(conn, denquery)
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
d...f <- sql...(conn, den...)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
dendf <- sqlQuery(conn, denquery)
```

</details>


Create a box plot of enrollements in elementary and secondary schools in Toronto.



```R
dendf$LEVEL <- as.factor(dendf$LEVEL)
boxplot(ENROLLMENT ~ LEVEL, dendf, names =c("Secondary","Elementary"), main="Toronto DSB")
```


![png](output_123_0.png)


<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
d...f$LEVEL <- as....(d...f$LEVEL)
box...(ENROLLMENT ~ ..., d...f, names =c("...","..."), ...="Toronto DSB")
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
dendf$LEVEL <- as.factor(dendf$LEVEL)
boxplot(ENROLLMENT ~ LEVEL, dendf, names =c("Secondary","Elementary"), main="Toronto DSB")
```

</details>


<a id="ref4j"></a>

### j. Dis-connect

Finally, as a best practice we should close the database connection once we're done with it.



```R
close(conn)
```

<details>
<summary>Click here to view/hide hint</summary>
<p>

```
# Fill in the ...
...(conn)
```

</details>


<details>
<summary>Click here to view/hide solution</summary>
<p>

```
close(conn)
```

</details>


<a id="ref4o"></a>

### Summary


In this lab you created and queried database objects from an R notebook in Jupyter, and you used ggplot2 to plot the data using R libraries.


<hr>


#### Thank you for completing this module on creating and querying database objects from R.


<hr>

## Authors

-   [Rav Ahuja](https://ca.linkedin.com/in/rav-ahuja-8aa4562a?cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ)
-   [Agatha Colangelo](https://www.linkedin.com/in/agathacolangelo?cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ)
-   [Sandip Saha Joy](https://www.linkedin.com/in/sandipsahajoy?cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ&cm_mmc=Email_Newsletter-_-Developer_Ed%2BTech-_-WW_WW-_-SkillsNetwork-Courses-IBMDeveloperSkillsNetwork-RP0103EN-SkillsNetwork-23619267&cm_mmca1=000026UJ&cm_mmca2=10006555&cm_mmca3=M12345678&cvosrc=email.Newsletter.M12345678&cvo_campaign=000026UJ)

## Changelog

| Date (YYYY-MM-DD) | Version | Changed By                   | Change Description                 |
| ----------------- | ------- | ---------------------------- | ---------------------------------- |
| 2021-01-22        | 2.0     | Sandip Saha Joy              | Created revised version of the lab |
| 2017              | 1.0     | Rav Ahuja & Agatha Colangelo | Created initial version of the lab |

<hr>

<h2 align=center><font size = 5>Copyright &copy; IBM Corporation 2017-2021. All rights reserved.</h2>

